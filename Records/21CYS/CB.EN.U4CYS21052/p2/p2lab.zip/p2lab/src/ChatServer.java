package com.amrita.cys21052;
import java.io.*;
import java.net.*;

public class ChatServer extends QuizGame {
    private static final String EXIT_COMMAND = "exit";
    private static final String QUESTION_MARKER = "? ";

    private DataInputStream dis;
    private DataOutputStream dout;

    public static void main(String[] args) {
        ChatServer server = new ChatServer();
        server.startGame();
    }

    @Override
    public void startGame() {
        try {
            ServerSocket ss = new ServerSocket(2444);
            Socket s = ss.accept();

            dis = new DataInputStream(s.getInputStream());
            dout = new DataOutputStream(s.getOutputStream());

            setListener(new QuizGameListener() {
                @Override
                public void onQuestionAsked(String question) {
                    try {
                        // Send the question to the client
                        dout.writeUTF(question + QUESTION_MARKER);
                        dout.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onAnswerEvaluated(boolean isCorrect) {
                    try {
                        String message = isCorrect ? "Correct!" : "Incorrect!";
                        // Send the result to the client
                        dout.writeUTF(message);
                        dout.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

            super.startGame();

            // Send the exit command
            dout.writeUTF(EXIT_COMMAND);
            dout.flush();

            ss.close();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }

    @Override
    protected int getQuestionCount() {
        return 3; // Modify as needed
    }

    @Override
    protected String askQuestion(int index) {
        // Modify the questions array as needed
        String[] questions = {
                "2 x 2",
                "4 x 4",
                "5 x 5"
        };
        return questions[index];
    }

    @Override
    protected void evaluateAnswer(int index, String answer) {
        // Modify the answers array as needed
        String[] answers = {
                "4",
                "16",
                "25"
        };
        String correctAnswer = answers[index];
        boolean isCorrect = answer.equalsIgnoreCase(correctAnswer);
        listener.onAnswerEvaluated(isCorrect);
    }
}