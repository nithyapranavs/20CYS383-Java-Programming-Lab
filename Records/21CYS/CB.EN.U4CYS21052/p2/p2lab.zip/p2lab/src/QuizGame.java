package com.amrita.cys21052;
public abstract class QuizGame {
    public QuizGameListener listener;

    public void setListener(QuizGameListener listener) {
        this.listener = listener;
    }

    public void startGame() {
        // Handle overall flow of the game
        for (int i = 0; i < getQuestionCount(); i++) {
            String question = askQuestion(i);
            listener.onQuestionAsked(question);

            String answer = waitForAnswer();
            evaluateAnswer(i, answer);
        }
    }

    protected abstract int getQuestionCount();

    protected abstract String askQuestion(int index);

    protected abstract void evaluateAnswer(int index, String answer);

    private String waitForAnswer() {
        // Implement logic to wait for the client's answer
        // and return the answer as a String
        return null;
    }
}