package com.amrita.cys21052;
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ChatClient {
    private static final String EXIT_COMMAND = "exit";
    private static final String QUESTION_MARKER = "? ";

    public static void main(String[] args) {
        try {
            Socket s = new Socket("localhost", 2444);

            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            DataInputStream dis = new DataInputStream(s.getInputStream());

            Scanner console = new Scanner(System.in);

            String str="";
            do {
                // Read the question from the server

                String question = dis.readUTF();
                System.out.print(question + QUESTION_MARKER);

                // Read the client's answer
                String clientAnswer = console.nextLine();

                // Send the answer to the server
                dout.writeUTF(clientAnswer);
                dout.flush();

                // Receive the result from the server
                String result = dis.readUTF();
                System.out.println("Server's Response: " + result);

            } while (!EXIT_COMMAND.equalsIgnoreCase(str));

            dout.close();
            s.close();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
}