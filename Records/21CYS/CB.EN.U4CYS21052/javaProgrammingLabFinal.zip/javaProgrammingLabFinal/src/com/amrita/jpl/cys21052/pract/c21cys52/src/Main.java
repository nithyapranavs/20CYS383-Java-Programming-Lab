import java.util.Scanner;
public class Main {
    double grade;
    String name;
    int roll;
    double mark1;
    double mark2;
    double mark3;
    public void getmark(){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Name: ");
        name=input.nextLine();
        System.out.println("Enter Roll No: ");
        roll=input.nextInt();
        System.out.println("Enter Mark 1: ");
        mark1=input.nextInt();
        System.out.println("Enter Mark 2: ");
        mark2=input.nextInt();
        System.out.println("Enter Mark 3: ");
        mark3=input.nextInt();
    }


    public char calcgrade(){
        double markAvg = (mark1 + mark2 + mark3)/3;
        char grade = 'f';
        if (markAvg > 40)
            grade = 'o';
        else if (markAvg > 35)
            grade = 'A';
        else if (markAvg >  30)
            grade = 'B';
        else if (markAvg > 20)
            grade = 'C';
        else if (markAvg > 10)
            grade = 'P';

        return grade;
    }
    public static void main(String[] args){
        Main obj=new Main();
        obj.getmark();
        System.out.println(obj.calcgrade());

    }
}

